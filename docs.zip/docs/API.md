# API atual

Base `/api`, JSON, sem cache de respostas privadas. Mutações exigem `Origin` igual a APP_URL, Content-Type JSON e corpo até 16 KiB. Sessão por cookie HttpOnly; não enviar token no JSON. Erros `{ error: { code, message } }` (podem incluir requestId), sem stack. 400 validação, 401 sessão inválida, 403 proibido, 404 recurso indisponível, 409 conflito/arquivamento, 429 limite, 503 integração ausente.

| Método    | Caminho                                 | Contrato resumido                                                 |
| --------- | --------------------------------------- | ----------------------------------------------------------------- |
| GET       | /health/live, /health/ready             | Processo; readiness consulta PostgreSQL                           |
| POST      | /auth/register                          | email, password, displayName; cria USER                           |
| POST      | /auth/login                             | email, password; cookie de sessão                                 |
| POST      | /auth/logout                            | revoga sessão e cookie                                            |
| POST      | /auth/forgot                            | email; envio SMTP se configurado; resposta não revela conta       |
| POST      | /auth/reset                             | token, password; uso único, revoga sessões                        |
| GET/PATCH | /me                                     | perfil; PATCH displayName, timezone                               |
| GET/POST  | /campaigns                              | lista com page (20/página); criação name, description opcional    |
| GET/PATCH | /campaigns/:id                          | detalhes; PATCH name, description, archived                       |
| GET/POST  | /campaigns/:id/invites                  | mestre; criação expiresInHours, maxUses; token/link só na criação |
| DELETE    | /campaigns/:id/invites/:inviteId        | mestre revoga                                                     |
| POST      | /invites/accept                         | token; entra PLAYER, idempotente para membro                      |
| PATCH     | /campaigns/:id/character-settings       | mestre: playersCanCreateCharacters, playersCanEditCharacters      |
| GET/POST  | /campaigns/:id/characters               | listagem page, 20/página; criação de ficha                        |
| GET/PATCH | /campaigns/:id/characters/:characterId  | ficha autorizada; PATCH exige expectedVersion                     |
| GET/POST  | /campaigns/:id/sessions                 | até 50 sessões; mestre cria title, description opcional           |
| GET/PATCH | /campaigns/:id/sessions/:sessionId      | sala; mestre altera status PLANNED/ACTIVE/FINISHED/CANCELLED      |
| POST      | /campaigns/:id/sessions/:sessionId/join | characterId; opcional para GM; ficha própria para jogador         |

Ficha: name, className, species, level (1–20), experience, hitPoints, maxHitPoints, temporaryHitPoints, armorClass, attributes {STR,DEX,CON,INT,WIS,CHA} inteiros 1–30. PV atuais não excedem máximos. ownerId opcional, só mestre pode atribuir a outro membro. PATCH envia todos os campos editáveis e expectedVersion; resposta contém modifiers, proficiency, canEdit e version. Campos adicionais são rejeitados. Contratos exatos em packages/contracts/src/core.ts, characters.ts e game-sessions.ts.

Limites atuais: participantes da campanha/sala até 100 na consulta; seletor inicial da sala usa primeira página de 20 fichas. Não há exclusão de ficha, saída da sala, delegação individual, mapa ou eventos Socket.IO nesta entrega. IDs da campanha sempre são verificados contra a associação do usuário. Dados de fichas alheias nunca são enviados a jogadores.

## Contratos de catálogo e sugestões

GET `/api/campaigns/:id/eligible-characters?q=texto` retorna até 20 pares id/name autorizados, busca por nome (máximo 120 caracteres); só o mestre recebe nomes de todas as fichas da campanha. Não é uma API pública. A página `/personagens?page=1` consulta somente fichas próprias.

POST/PATCH de ficha aceitam também classId/speciesId/backgroundId/subclassId (opcionais, null para manual) e backgroundName/subclassName (até 80 caracteres). IDs são validados contra o catálogo; nomes precisam corresponder; subclasse exige classe correspondente e nível mínimo. Campos omitidos no PATCH são preservados. campaignId no corpo continua proibido; a campanha vem da rota autorizada. O retorno à sessão usa somente UUID de sessão cuja campanha e acesso foram verificados pelo servidor.

## Extensão de fichas: classes relacionais

POST `/api/campaigns/:campaignId/characters` e PATCH `/api/campaigns/:campaignId/characters/:id` aceitam `classes` e `multiclassAdjustment`. O array contém classId/className, subclassId/subclassName, level, rulesVersion, sourceId/subclassSourceId e acquisitionLevels. IDs de catálogo podem ser null para opção manual; fontes registradas são resolvidas pelo servidor. O nível total é calculado, mantendo level escalar como projeção. PATCH requer expectedVersion. Omissão de classes em ficha multiclasse retorna 409 CLASSES_REQUIRED. Erros de distribuição/requisitos retornam 400 INVALID_MULTICLASS; tentativa de conceder ajuste por jogador retorna 403 GM_ADJUSTMENT_REQUIRED. Retornos detalhados incluem classes; os campos de primeira classe continuam para compatibilidade. Ver [MULTICLASSE.md](MULTICLASSE.md) e fixture de teste `tests/fixtures/swarm.ts`.
